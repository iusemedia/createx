
document.querySelectorAll('[data-year]').forEach(e=>e.textContent=new Date().getFullYear());
document.querySelectorAll('[data-timer]').forEach(el=>{
  let seconds=10800;
  const saved=localStorage.getItem('assessmentTimerStart');
  if(saved){seconds=Math.max(0,10800-Math.floor((Date.now()-Number(saved))/1000))}
  else localStorage.setItem('assessmentTimerStart',Date.now());
  const tick=()=>{let h=Math.floor(seconds/3600),m=Math.floor(seconds%3600/60),s=seconds%60;
    el.textContent=`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
    if(seconds<=0){location.href='04-formats-sales-standard.html'} else {seconds--;setTimeout(tick,1000)}
  };tick();
});
