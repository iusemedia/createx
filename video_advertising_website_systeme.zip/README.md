# Video Advertising Website — Systeme.io Build

This is a polished static front-end prototype based strictly on the supplied 10-page project brief.

## Public navigation
Home, Courses, About, Contact.

## Public standard offers
- Five Video Ad Formats — $19 lifetime access
- Video Advertising Formula — $197

## Private funnel pages
Checklist, assessment landing/quiz/results, $7 Formats assessment offer, $97 first-50 Formula assessment offer.

## Important
The brief does not provide final brand name, logo, legal copy, product video URLs, PDF/Word file URLs, payment provider configuration, or final email copy. Those are intentionally left as integration points rather than invented.

## Systeme.io implementation
Replace static form/buttons with Systeme.io forms, checkout elements, survey elements, member-area links, automation triggers, tags, and tracking scripts according to the supplied project brief.
